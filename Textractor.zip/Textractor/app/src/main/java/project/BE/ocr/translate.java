package project.BE.ocr;

public class translate {
}
